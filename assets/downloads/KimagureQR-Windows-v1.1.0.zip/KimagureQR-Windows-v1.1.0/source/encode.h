#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include "qrcodegen.h"
namespace Kimagure {
struct Code { std::string url; std::vector<uint8_t> data; int size = 1024; int level = 1; };
Code EncodeNormalized(const std::string& url, int pixels, int level);
std::string PngBytes(const Code& code);
std::string SvgBytes(const Code& code);
}
