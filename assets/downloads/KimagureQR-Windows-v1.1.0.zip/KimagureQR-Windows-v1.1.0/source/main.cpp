#include "core.h"
#include <objidl.h>
#include <commctrl.h>
#include <commdlg.h>
#include <shellapi.h>
#include <algorithm>
#include <memory>
#include <stdexcept>

using namespace Kimagure;
static HINSTANCE instance;
static HWND windowHandle, urlEdit, sizeCombo, eccCombo, generateButton, clearButton, pngButton, svgButton, destination;
static HFONT fontNormal, fontSmall, fontTitle, fontBold;
static HBRUSH whiteBrush;
static double scaleFactor = 1;
static RECT previewRect, leftPanel, rightPanel;
static std::unique_ptr<Code> current;
static std::wstring messageText, lastDirectory;
static bool isError = false;
enum { URL_ID = 101, SIZE_ID, ECC_ID, GENERATE_ID, CLEAR_ID, PNG_ID, SVG_ID, DEST_ID };
static int S(int value) { return int(value * scaleFactor + .5); }
static std::wstring Text(HWND control) {
    int length = GetWindowTextLengthW(control); std::wstring text(length + 1, 0);
    GetWindowTextW(control, text.data(), length + 1); text.resize(length); return text;
}
static void SetMessage(const std::wstring& text, bool error = false) { messageText = text; isError = error; InvalidateRect(windowHandle, nullptr, FALSE); }
static HFONT MakeFont(int px, int weight) { return CreateFontW(-S(px), 0, 0, 0, weight, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH, L"Yu Gothic UI"); }
static void UpdateFonts() {
    RECT work; SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
    double requested = GetDpiForWindow(windowHandle) / 96.0;
    scaleFactor = std::min(requested, std::max(.9, (work.bottom - work.top - 40) / 690.0));
    for (HFONT f : {fontNormal, fontSmall, fontTitle, fontBold}) if (f) DeleteObject(f);
    fontNormal = MakeFont(14, FW_NORMAL); fontSmall = MakeFont(12, FW_NORMAL); fontTitle = MakeFont(25, FW_BOLD); fontBold = MakeFont(16, FW_BOLD);
    for (HWND h : {urlEdit, sizeCombo, eccCombo, generateButton, clearButton, pngButton, svgButton, destination}) if (h) SendMessageW(h, WM_SETFONT, WPARAM(h == clearButton || h == destination ? fontSmall : fontNormal), TRUE);
}
static HWND Control(const wchar_t* cls, const wchar_t* text, DWORD style, int id, DWORD ex = 0) {
    HWND h = CreateWindowExW(ex, cls, text, WS_CHILD | WS_VISIBLE | style, 0, 0, 1, 1, windowHandle, HMENU(INT_PTR(id)), instance, nullptr);
    if (!h) throw std::runtime_error("画面を作成できませんでした．");
    return h;
}
static void Layout() {
    RECT client; GetClientRect(windowHandle, &client); int w = client.right, h = client.bottom;
    int gap = S(20), margin = S(24), width = (w - margin * 2 - gap) / 2;
    leftPanel = {margin, S(116), margin + width, h - S(42)};
    rightPanel = {margin + width + gap, S(116), w - margin, h - S(42)};
    int x = leftPanel.left + S(22), inner = width - S(44), right = rightPanel.left + S(22), rwidth = rightPanel.right - right - S(22);
    MoveWindow(clearButton, x + inner - S(94), S(176), S(94), S(28), TRUE);
    MoveWindow(urlEdit, x, S(210), inner, S(90), TRUE);
    MoveWindow(sizeCombo, x, S(362), (inner - S(12)) / 2, S(200), TRUE);
    MoveWindow(eccCombo, x + (inner + S(12)) / 2, S(362), (inner - S(12)) / 2, S(200), TRUE);
    MoveWindow(generateButton, x, S(412), inner, S(44), TRUE);
    previewRect = {right, S(180), right + rwidth, h - S(210)};
    MoveWindow(destination, right, h - S(174), rwidth, S(48), TRUE);
    MoveWindow(pngButton, right, h - S(112), (rwidth - S(10)) / 2, S(38), TRUE);
    MoveWindow(svgButton, right + (rwidth + S(10)) / 2, h - S(112), (rwidth - S(10)) / 2, S(38), TRUE);
    InvalidateRect(windowHandle, nullptr, TRUE);
}
static void InvalidateCode() {
    current.reset(); EnableWindow(pngButton, FALSE); EnableWindow(svgButton, FALSE);
    SetWindowTextW(destination, L""); SetMessage(L"");
}
static void GenerateCode() {
    try {
        int sizes[] = {512, 1024, 2048, 4096}, levels[] = {1, 2, 3, 0};
        int si = int(SendMessageW(sizeCombo, CB_GETCURSEL, 0, 0)), ei = int(SendMessageW(eccCombo, CB_GETCURSEL, 0, 0));
        InvalidateCode();
        if (si < 0 || si > 3 || ei < 0 || ei > 3) throw std::runtime_error("画像の設定を選び直してください．");
        current = std::make_unique<Code>(Generate(Text(urlEdit), sizes[si], levels[ei]));
        SetWindowTextW(destination, Wide(current->url).c_str()); EnableWindow(pngButton, TRUE); EnableWindow(svgButton, TRUE);
        SetMessage(L"作成しました．PNGまたはSVGで保存できます．");
    } catch (const std::exception& e) { InvalidateCode(); SetMessage(Wide(e.what()), true); }
}
static void Save(bool svg) {
    if (!current) return;
    std::vector<wchar_t> path(32768, 0);
    const wchar_t* defaultName = svg ? L"kimagure-qr.svg" : L"kimagure-qr.png";
    wcscpy_s(path.data(), path.size(), defaultName);
    OPENFILENAMEW dialog{}; dialog.lStructSize = sizeof(dialog); dialog.hwndOwner = windowHandle;
    dialog.lpstrFile = path.data(); dialog.nMaxFile = DWORD(path.size()); dialog.nFilterIndex = 1;
    dialog.lpstrFilter = svg ? L"SVG画像 (*.svg)\0*.svg\0\0" : L"PNG画像 (*.png)\0*.png\0\0";
    dialog.lpstrDefExt = svg ? L"svg" : L"png"; dialog.lpstrTitle = L"QRコードに名前を付けて保存";
    dialog.lpstrInitialDir = lastDirectory.empty() ? nullptr : lastDirectory.c_str();
    dialog.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | OFN_EXPLORER;
    if (!GetSaveFileNameW(&dialog)) {
        if (CommDlgExtendedError() != 0) SetMessage(L"保存画面を開けませんでした．別の保存先でお試しください．", true);
        return;
    }
    try {
        if (svg) SaveSvg(*current, path.data()); else SavePng(*current, path.data());
        std::wstring saved(path.data()); auto slash = saved.find_last_of(L"\\/");
        if (slash != std::wstring::npos) lastDirectory = saved.substr(0, slash);
        SetMessage(L"保存しました：" + saved.substr(slash == std::wstring::npos ? 0 : slash + 1));
    } catch (const std::exception& e) { SetMessage(Wide(e.what()), true); }
}
static void Fill(HDC dc, RECT rect, COLORREF color) { HBRUSH brush = CreateSolidBrush(color); FillRect(dc, &rect, brush); DeleteObject(brush); }
static void Label(HDC dc, const std::wstring& text, RECT rect, HFONT font, COLORREF color, UINT flags = DT_LEFT | DT_TOP | DT_WORDBREAK) {
    int saved = SaveDC(dc);
    SelectObject(dc, font); SetTextColor(dc, color); SetBkMode(dc, TRANSPARENT); DrawTextW(dc, text.c_str(), -1, &rect, flags | DT_NOPREFIX);
    RestoreDC(dc, saved);
}
static void Paint(HDC dc, const RECT& client) {
    int w = client.right, h = client.bottom;
    const COLORREF ink = RGB(32,32,34), muted = RGB(97,96,102), red = RGB(183,0,0);
    Fill(dc, client, RGB(245,244,241)); Fill(dc, {0, 0, w, S(82)}, RGB(255,255,255));
    Fill(dc, {S(24), S(21), S(62), S(59)}, red);
    Label(dc, L"QR", {S(25), S(26), S(61), S(59)}, fontBold, RGB(255,255,255), DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    Label(dc, L"気まぐれQR", {S(77), S(13), w-S(240), S(52)}, fontTitle, ink);
    Label(dc, L"気まぐれの館  /  Windows専用アプリ", {S(79), S(51), w-S(240), S(76)}, fontSmall, muted);
    Label(dc, L"ネット接続なしで作成・保存", {w-S(245), S(29), w-S(24), S(55)}, fontSmall, RGB(38,108,64), DT_RIGHT | DT_SINGLELINE);
    Label(dc, L"URLを貼り付けて，作って，保存する．", {S(25), S(91), w-S(25), S(113)}, fontSmall, muted);
    Fill(dc, leftPanel, RGB(255,255,255)); Fill(dc, rightPanel, RGB(255,255,255));
    int x = leftPanel.left + S(22), right = rightPanel.left + S(22), end = leftPanel.right - S(22);
    Label(dc, L"01  リンクを入力", {x, S(134), end, S(164)}, fontBold, ink);
    Label(dc, L"02  プレビュー・保存", {right, S(134), rightPanel.right-S(22), S(164)}, fontBold, ink);
    Label(dc, L"QRコードにするURL", {x, S(181), end-S(98), S(205)}, fontNormal, ink);
    Label(dc, L"https:// を省いた場合は，自動で補います．", {x, S(306), end, S(331)}, fontSmall, muted);
    Label(dc, L"画像サイズ", {x, S(338), x+S(135), S(360)}, fontSmall, ink);
    Label(dc, L"汚れ・欠けへの強さ", {x+(end-x+S(12))/2, S(338), end, S(360)}, fontSmall, ink);
    Label(dc, messageText, {x, S(468), end, h-S(126)}, fontSmall, isError ? red : RGB(38,108,64));
    Fill(dc, {x, h-S(121), end, h-S(120)}, RGB(232,230,226));
    Label(dc, L"URLを直接記録．アプリ側の有効期限はありません．\nリンク先が閉鎖・変更された場合は開けなくなります．", {x, h-S(109), end, h-S(50)}, fontSmall, muted);
    Fill(dc, previewRect, RGB(247,247,245));
    if (current) {
        int n = qrcodegen_getSize(current->data.data());
        int unit = std::max<int>(1, std::min(previewRect.right-previewRect.left-S(16), previewRect.bottom-previewRect.top-S(16)) / (n+8));
        int side = (n+8)*unit, left = (previewRect.left+previewRect.right-side)/2, top=(previewRect.top+previewRect.bottom-side)/2;
        Fill(dc, {left,top,left+side,top+side}, RGB(255,255,255));
        HBRUSH black = static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
        for (int yy=0; yy<n; ++yy) for(int xx=0;xx<n;++xx) if(qrcodegen_getModule(current->data.data(),xx,yy)) {
            RECT block{left+(xx+4)*unit,top+(yy+4)*unit,left+(xx+5)*unit,top+(yy+5)*unit}; FillRect(dc,&block,black);
        }
    } else {
        Label(dc, L"ここにQRコードが表示されます", previewRect, fontNormal, muted, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    }
    Label(dc, current ? L"記録したURL  /  " + std::to_wstring(current->size) + L" × " + std::to_wstring(current->size) + L" px" : L"白背景・黒のコード・読み取り用の余白付き", {right, h-S(201), rightPanel.right-S(22), h-S(178)}, fontSmall, muted);
    Label(dc, L"PNG：画像素材に  ／  SVG：拡大・印刷に", {right, h-S(66), rightPanel.right-S(22), h-S(45)}, fontSmall, muted, DT_CENTER | DT_SINGLELINE);
    Label(dc, L"好きだから，本気になれる．", {S(25),h-S(29),w/2,h-S(5)}, fontSmall, muted);
    Label(dc, L"外部への送信なし  |  v1.1.0", {w/2,h-S(29),w-S(25),h-S(5)}, fontSmall, muted, DT_RIGHT | DT_SINGLELINE);
}
static void DrawButton(const DRAWITEMSTRUCT& draw) {
    const bool disabled = draw.itemState & ODS_DISABLED, pressed = draw.itemState & ODS_SELECTED;
    COLORREF color = draw.CtlID == GENERATE_ID ? RGB(183,0,0) : RGB(40,40,43);
    if (disabled) color = RGB(225,223,220); else if (pressed) color = RGB(95,0,0);
    Fill(draw.hDC, draw.rcItem, color);
    Label(draw.hDC, Text(draw.hwndItem), draw.rcItem, fontNormal, disabled ? RGB(140,137,133) : RGB(255,255,255), DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    if (draw.itemState & ODS_FOCUS) { RECT r=draw.rcItem; InflateRect(&r,-S(4),-S(4)); DrawFocusRect(draw.hDC,&r); }
}
static LRESULT CALLBACK Proc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    switch (message) {
    case WM_CREATE:
        windowHandle = hwnd;
        try {
            urlEdit = Control(L"EDIT", L"", WS_TABSTOP | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL, URL_ID, WS_EX_CLIENTEDGE);
            SendMessageW(urlEdit, EM_SETLIMITTEXT, 8000, 0);
            sizeCombo = Control(WC_COMBOBOXW, L"", WS_TABSTOP | CBS_DROPDOWNLIST, SIZE_ID);
            eccCombo = Control(WC_COMBOBOXW, L"", WS_TABSTOP | CBS_DROPDOWNLIST, ECC_ID);
            for (auto text : {L"512 × 512 px", L"1024 × 1024 px", L"2048 × 2048 px", L"4096 × 4096 px"}) SendMessageW(sizeCombo, CB_ADDSTRING, 0, LPARAM(text));
            for (auto text : {L"標準（M）", L"強め（Q）", L"最大（H）", L"長いURL向け（L）"}) SendMessageW(eccCombo, CB_ADDSTRING, 0, LPARAM(text));
            SendMessageW(sizeCombo, CB_SETCURSEL, 1, 0); SendMessageW(eccCombo, CB_SETCURSEL, 0, 0);
            generateButton = Control(L"BUTTON", L"QRコードを作成", WS_TABSTOP | BS_OWNERDRAW, GENERATE_ID);
            clearButton = Control(L"BUTTON", L"入力を消す", WS_TABSTOP | BS_PUSHBUTTON, CLEAR_ID);
            destination = Control(L"EDIT", L"", WS_TABSTOP | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL | WS_VSCROLL, DEST_ID);
            pngButton = Control(L"BUTTON", L"PNGで保存", WS_TABSTOP | BS_OWNERDRAW, PNG_ID);
            svgButton = Control(L"BUTTON", L"SVGで保存", WS_TABSTOP | BS_OWNERDRAW, SVG_ID);
            EnableWindow(pngButton, FALSE); EnableWindow(svgButton, FALSE);
            UpdateFonts(); Layout(); SetFocus(urlEdit);
        } catch (const std::exception& e) { MessageBoxW(hwnd, Wide(e.what()).c_str(), L"気まぐれQR", MB_ICONERROR); return -1; }
        return 0;
    case WM_SIZE: if (urlEdit) Layout(); return 0;
    case WM_DPICHANGED: { UpdateFonts(); const RECT* r = reinterpret_cast<RECT*>(lParam); SetWindowPos(hwnd,nullptr,r->left,r->top,r->right-r->left,r->bottom-r->top,SWP_NOZORDER|SWP_NOACTIVATE); Layout(); return 0; }
    case WM_GETMINMAXINFO: {
        auto m = reinterpret_cast<MINMAXINFO*>(lParam); m->ptMinTrackSize.x=S(870); m->ptMinTrackSize.y=S(662); return 0;
    }
    case WM_COMMAND:
        if (LOWORD(wParam)==URL_ID && HIWORD(wParam)==EN_CHANGE) InvalidateCode();
        else if ((LOWORD(wParam)==SIZE_ID || LOWORD(wParam)==ECC_ID) && HIWORD(wParam)==CBN_SELCHANGE) { if (current) GenerateCode(); }
        else if (HIWORD(wParam)==BN_CLICKED) switch (LOWORD(wParam)) {
            case GENERATE_ID: GenerateCode(); break;
            case CLEAR_ID: SetWindowTextW(urlEdit,L""); InvalidateCode(); SetFocus(urlEdit); break;
            case PNG_ID: Save(false); break; case SVG_ID: Save(true); break;
        }
        return 0;
    case WM_DRAWITEM: DrawButton(*reinterpret_cast<DRAWITEMSTRUCT*>(lParam)); return TRUE;
    case WM_CTLCOLOREDIT: case WM_CTLCOLORSTATIC: SetBkColor(HDC(wParam),RGB(255,255,255)); SetTextColor(HDC(wParam),RGB(32,32,34)); return LRESULT(whiteBrush);
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: { PAINTSTRUCT ps; HDC screen=BeginPaint(hwnd,&ps); RECT client;GetClientRect(hwnd,&client); HDC mem=CreateCompatibleDC(screen); HBITMAP bmp=CreateCompatibleBitmap(screen,client.right,client.bottom); HGDIOBJ old=SelectObject(mem,bmp); Paint(mem,client);BitBlt(screen,0,0,client.right,client.bottom,mem,0,0,SRCCOPY);SelectObject(mem,old);DeleteObject(bmp);DeleteDC(mem);EndPaint(hwnd,&ps);return 0; }
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(hwnd,message,wParam,lParam);
}
int WINAPI wWinMain(HINSTANCE inst,HINSTANCE,LPWSTR,int show) {
    instance=inst;
    if (FAILED(CoInitializeEx(nullptr,COINIT_APARTMENTTHREADED))) { MessageBoxW(nullptr,L"アプリを開始できませんでした．再度起動してください．",L"気まぐれQR",MB_ICONERROR);return 1; }
    INITCOMMONCONTROLSEX common{sizeof(common),ICC_STANDARD_CLASSES};InitCommonControlsEx(&common);
    whiteBrush=CreateSolidBrush(RGB(255,255,255));
    WNDCLASSEXW cls{};cls.cbSize=sizeof(cls);cls.lpfnWndProc=Proc;cls.hInstance=inst;cls.lpszClassName=L"KimagureQR.Native";cls.hCursor=LoadCursorW(nullptr,IDC_ARROW);cls.hIcon=LoadIconW(inst,MAKEINTRESOURCEW(1));cls.hIconSm=cls.hIcon;RegisterClassExW(&cls);
    HWND hwnd=CreateWindowExW(WS_EX_CONTROLPARENT,cls.lpszClassName,L"気まぐれQR — Windows版",WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,960,700,nullptr,nullptr,inst,nullptr);
    if(!hwnd) { CoUninitialize();return 1; }
    RECT work;SystemParametersInfoW(SPI_GETWORKAREA,0,&work,0);
    int width=std::min<int>(S(980),work.right-work.left-S(20)),height=std::min<int>(S(700),work.bottom-work.top-S(20));
    SetWindowPos(hwnd,nullptr,work.left+(work.right-work.left-width)/2,work.top+(work.bottom-work.top-height)/2,width,height,SWP_NOZORDER);
    ShowWindow(hwnd,show);UpdateWindow(hwnd);SetFocus(urlEdit);
    MSG msg;while(GetMessageW(&msg,nullptr,0,0)>0){
        if(msg.message==WM_KEYDOWN && msg.wParam==VK_RETURN && (GetKeyState(VK_CONTROL)&0x8000)){GenerateCode();continue;}
        if(msg.message==WM_KEYDOWN && msg.wParam=='A' && (GetKeyState(VK_CONTROL)&0x8000) && (GetFocus()==urlEdit || GetFocus()==destination)){SendMessageW(GetFocus(),EM_SETSEL,0,-1);continue;}
        if(!IsDialogMessageW(hwnd,&msg)){TranslateMessage(&msg);DispatchMessageW(&msg);}
    }
    for(HFONT f:{fontNormal,fontSmall,fontTitle,fontBold}) DeleteObject(f);
    DeleteObject(whiteBrush);
    CoUninitialize();return int(msg.wParam);
}
