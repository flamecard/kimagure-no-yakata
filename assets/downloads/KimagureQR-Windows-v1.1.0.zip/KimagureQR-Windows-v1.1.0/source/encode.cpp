#include "encode.h"
#include <algorithm>
#include <sstream>
#include <stdexcept>

namespace Kimagure {
Code EncodeNormalized(const std::string& url, int pixels, int level) {
    if ((pixels != 512 && pixels != 1024 && pixels != 2048 && pixels != 4096) || level < 0 || level > 3)
        throw std::runtime_error("画像の設定が不正です．");
    if (url.empty() || url.size() > 2953) throw std::runtime_error("URLが長すぎます．短いURLを使ってください．");
    Code code; code.url = url; code.size = pixels; code.level = level; code.data.resize(qrcodegen_BUFFER_LEN_MAX);
    std::vector<uint8_t> scratch(qrcodegen_BUFFER_LEN_MAX);
    if (!qrcodegen_encodeText(url.c_str(), scratch.data(), code.data.data(), static_cast<qrcodegen_Ecc>(level), 1, 40, qrcodegen_Mask_AUTO, false))
        throw std::runtime_error("この設定ではURLが長すぎます．「長いURL向け（L）」か，短いURLを使ってください．");
    return code;
}
static void Big32(std::string& out, uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) out.push_back(char((value >> shift) & 255));
}
static uint32_t Crc32(const char* data, size_t length) {
    uint32_t crc = 0xffffffffu;
    for (size_t i = 0; i < length; ++i) {
        crc ^= static_cast<uint8_t>(data[i]);
        for (int bit = 0; bit < 8; ++bit) crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
    }
    return crc ^ 0xffffffffu;
}
static void Chunk(std::string& out, const char type[5], const std::string& bytes) {
    Big32(out, uint32_t(bytes.size())); size_t start = out.size(); out.append(type, 4); out += bytes;
    Big32(out, Crc32(out.data() + start, bytes.size() + 4));
}
std::string PngBytes(const Code& code) {
    // PNG grayscale depth 1. Integer modules and a quiet zone >= 4 modules.
    // RFC 1950/1951 stored DEFLATE blocks keep the encoder self-contained.
    const int n = qrcodegen_getSize(code.data.data()), scale = code.size / (n + 8), offset = (code.size - n * scale) / 2;
    const int stride = (code.size + 7) / 8 + 1;
    std::string raw(size_t(stride) * code.size, char(255));
    for (int y = 0; y < code.size; ++y) raw[size_t(y) * stride] = 0; // Filter type None.
    for (int my = 0; my < n; ++my) for (int mx = 0; mx < n; ++mx) if (qrcodegen_getModule(code.data.data(), mx, my))
        for (int y = offset + my * scale; y < offset + (my + 1) * scale; ++y)
            for (int x = offset + mx * scale; x < offset + (mx + 1) * scale; ++x) {
                size_t index = size_t(y) * stride + 1 + x / 8;
                raw[index] = char(static_cast<uint8_t>(raw[index]) & ~(1u << (7 - x % 8)));
            }
    std::string zlib("\x78\x01", 2); uint32_t a = 1, b = 0;
    for (unsigned char c : raw) { a = (a + c) % 65521u; b = (b + a) % 65521u; }
    for (size_t offset = 0; offset < raw.size();) {
        size_t count = std::min<size_t>(65535, raw.size() - offset);
        zlib.push_back(offset + count == raw.size() ? char(1) : char(0));
        uint16_t length = uint16_t(count), inverse = uint16_t(~length);
        zlib.push_back(char(length & 255)); zlib.push_back(char(length >> 8));
        zlib.push_back(char(inverse & 255)); zlib.push_back(char(inverse >> 8));
        zlib.append(raw, offset, count); offset += count;
    }
    Big32(zlib, (b << 16) | a);
    std::string png("\x89PNG\r\n\x1a\n", 8), header;
    Big32(header, uint32_t(code.size)); Big32(header, uint32_t(code.size));
    header.append("\x01\x00\x00\x00\x00", 5);
    Chunk(png, "IHDR", header); Chunk(png, "IDAT", zlib); Chunk(png, "IEND", "");
    return png;
}
std::string SvgBytes(const Code& code) {
    const int n = qrcodegen_getSize(code.data.data()), dim = n + 8;
    std::ostringstream svg;
    svg << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 " << dim << ' ' << dim << "\" width=\"" << code.size << "\" height=\"" << code.size << "\" shape-rendering=\"crispEdges\"><title>QR Code</title><rect width=\"100%\" height=\"100%\" fill=\"#ffffff\"/><path fill=\"#000000\" d=\"";
    for (int y = 0; y < n; ++y) for (int x = 0; x < n; ++x) if (qrcodegen_getModule(code.data.data(), x, y))
        svg << 'M' << x + 4 << ',' << y + 4 << "h1v1h-1z";
    svg << "\"/></svg>\n"; return svg.str();
}
}
