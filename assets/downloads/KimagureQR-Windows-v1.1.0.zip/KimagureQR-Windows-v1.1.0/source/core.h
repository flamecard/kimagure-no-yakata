#pragma once
#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define NOMINMAX
#include <windows.h>
#include <string>
#include <vector>
#include <cstdint>
#include "encode.h"

namespace Kimagure {
std::string Utf8(const std::wstring& text);
std::wstring Wide(const std::string& text);
std::string NormalizeUrl(const std::wstring& text);
Code Generate(const std::wstring& text, int pixels, int level);
void SavePng(const Code& code, const std::wstring& path);
void SaveSvg(const Code& code, const std::wstring& path);
void WriteFileBytes(const std::wstring& path, const std::string& bytes);
}
