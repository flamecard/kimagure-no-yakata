@echo off
setlocal
cd /d "%~dp0"
rem Developer build only. End users should launch the included KimagureQR.exe.
rem Requires a MinGW-w64 64-bit C/C++ toolchain in PATH.
gcc -std=c99 -Os -Wall -Wextra -c qrcodegen.c -o qrcodegen.o
if errorlevel 1 goto fail
windres app.rc -O coff -o app.res
if errorlevel 1 goto fail
g++ -std=c++17 -Os -s -Wall -Wextra -municode -mwindows -static -static-libgcc -static-libstdc++ main.cpp core.cpp encode.cpp qrcodegen.o app.res -o "..\KimagureQR.exe" -lcomctl32 -lcomdlg32 -lole32 -loleaut32 -lurlmon -lnormaliz -lgdi32 -luuid -Wl,--dynamicbase,--nxcompat
if errorlevel 1 goto fail
echo Build complete: ..\KimagureQR.exe
exit /b 0
:fail
echo Build failed. Check the compiler output above.
pause
exit /b 1
