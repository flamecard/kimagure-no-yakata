#include "core.h"
#include <objidl.h>
#include <urlmon.h>
#include <winnls.h>
#include <algorithm>
#include <cwctype>
#include <memory>
#include <sstream>
#include <stdexcept>

namespace Kimagure {
static void Fail(const char* message) { throw std::runtime_error(message); }
std::string Utf8(const std::wstring& text) {
    if (text.empty()) return {};
    int size = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(), int(text.size()), nullptr, 0, nullptr, nullptr);
    if (!size) Fail("文字を変換できませんでした．URLをコピーし直してください．");
    std::string out(size, 0);
    WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, text.data(), int(text.size()), out.data(), size, nullptr, nullptr);
    return out;
}
std::wstring Wide(const std::string& text) {
    if (text.empty()) return {};
    int size = MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), int(text.size()), nullptr, 0);
    std::wstring out(size, 0);
    if (size) MultiByteToWideChar(CP_UTF8, MB_ERR_INVALID_CHARS, text.data(), int(text.size()), out.data(), size);
    return out;
}
struct UriDeleter { void operator()(IUri* value) const { if (value) value->Release(); } };
static std::wstring Take(BSTR text) { std::wstring result(text ? text : L"", SysStringLen(text)); SysFreeString(text); return result; }
std::string NormalizeUrl(const std::wstring& text) {
    const auto first = text.find_first_not_of(L" \r\n\t");
    if (first == std::wstring::npos) Fail("URLを入力してください．");
    std::wstring input = text.substr(first, text.find_last_not_of(L" \r\n\t") - first + 1);
    if (input.size() > 8000) Fail("URLが長すぎます．短いURLを使ってください．");
    for (wchar_t c : input) if (iswspace(c) || c < 0x20 || c == L'\\') Fail("URLの途中に空白・改行・「\\」があります．リンクをコピーし直してください．");
    std::wstring lower = input; std::transform(lower.begin(), lower.end(), lower.begin(), towlower);
    if (lower.rfind(L"https://", 0) != 0 && lower.rfind(L"http://", 0) != 0) {
        const auto colon = input.find(L':');
        if (input.find(L"://") != std::wstring::npos || (colon != std::wstring::npos && input[0] != L'[' && input.substr(0, colon).find(L'.') == std::wstring::npos && input.substr(0, colon) != L"localhost"))
            Fail("http:// または https:// のWebページのURLを入力してください．");
        input = L"https://" + input;
    }
    IUri* raw = nullptr;
    HRESULT hr = CreateUri(input.c_str(), Uri_CREATE_CANONICALIZE | Uri_CREATE_NO_DECODE_EXTRA_INFO | Uri_CREATE_NO_IE_SETTINGS, 0, &raw);
    if (FAILED(hr) || !raw) Fail("URLの形式を確認してください．例：https://example.com");
    std::unique_ptr<IUri, UriDeleter> uri(raw);
    BSTR value = nullptr;
    if (FAILED(uri->GetUserInfo(&value))) Fail("URLを確認してください．");
    if (!Take(value).empty()) Fail("ユーザー名・パスワードを含まないURLを入力してください．");
    value = nullptr; uri->GetHost(&value); std::wstring host = Take(value);
    if (host.empty()) Fail("ドメイン名を入力してください．例：example.com");
    if (host.find(L'.') == std::wstring::npos && host.find(L':') == std::wstring::npos && host != L"localhost") Fail("ドメイン名を確認してください．例：example.com");
    value = nullptr; uri->GetAbsoluteUri(&value); std::wstring absolute = Take(value);
    if (absolute.empty()) Fail("URLを変換できませんでした．");
    if (host.find(L':') == std::wstring::npos) {
        int length = IdnToAscii(IDN_USE_STD3_ASCII_RULES, host.data(), int(host.size()), nullptr, 0);
        if (!length) Fail("ドメイン名に使えない文字が含まれています．");
        std::wstring ascii(length, 0); IdnToAscii(IDN_USE_STD3_ASCII_RULES, host.data(), int(host.size()), ascii.data(), length);
        const auto authorityStart = absolute.find(L"://") + 3;
        const auto authorityEnd = absolute.find_first_of(L"/?#", authorityStart);
        std::wstring authority = absolute.substr(authorityStart, authorityEnd - authorityStart);
        const auto port = authority.find(L':');
        std::wstring suffix = port == std::wstring::npos ? L"" : authority.substr(port);
        absolute.replace(authorityStart, authority.size(), ascii + suffix);
    }
    std::string bytes = Utf8(absolute), result;
    static const char hex[] = "0123456789ABCDEF";
    for (unsigned char c : bytes) {
        if (c >= 0x80 || c == '"' || c == '<' || c == '>' || c == '`' || c == '{' || c == '}' || c == '|') {
            result += '%'; result += hex[c >> 4]; result += hex[c & 15];
        } else result += char(c);
    }
    for (size_t i = 0; i < result.size(); ++i) if (result[i] == '%' && (i + 2 >= result.size() || !isxdigit(static_cast<unsigned char>(result[i+1])) || !isxdigit(static_cast<unsigned char>(result[i+2]))))
        Fail("URLの「%」の後ろが不正です．ブラウザーのアドレス欄からコピーし直してください．");
    return result;
}
Code Generate(const std::wstring& text, int pixels, int level) {
    return EncodeNormalized(NormalizeUrl(text), pixels, level);
}
void WriteFileBytes(const std::wstring& path, const std::string& bytes) {
    HANDLE file = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) Fail("保存できませんでした．保存先とファイルの使用状況を確認してください．");
    DWORD written = 0; bool ok = WriteFile(file, bytes.data(), DWORD(bytes.size()), &written, nullptr) != 0;
    if (ok) ok = FlushFileBuffers(file) != 0;
    CloseHandle(file);
    if (!ok || written != bytes.size()) Fail("保存を完了できませんでした．空き容量と保存先を確認してください．");
}
void SavePng(const Code& code, const std::wstring& path) {
    WriteFileBytes(path, PngBytes(code));
}
void SaveSvg(const Code& code, const std::wstring& path) {
    WriteFileBytes(path, SvgBytes(code));
}
}
